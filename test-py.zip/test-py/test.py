import os
import glob
import json

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from transformers import (
    Wav2Vec2CTCTokenizer,
    Wav2Vec2FeatureExtractor,
    Wav2Vec2Processor,
    Wav2Vec2ForCTC,
)

from constants_test import *
from utils_test import *
from models import *


file_prefix = "multitask"
augment = False

# Hyperparameters (not used)
# learning_rate = 3e-4
# num_epochs = 450
batch_size = 8
projection_hidden_size = 256

model_path = "facebook/wav2vec2-xls-r-300m"
backbone_hidden_size = 1024  # this depends on the pre trained model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)


print("Loading the data...")
# get the data and segregate them
speaker_paths = glob.glob(os.path.join(DATA_ROOT, "*", "*"))
waveform_paths, lm_labels, accent_labels, gender_labels = get_data_from_speaker_paths(
    speaker_paths
)

# prepare the vocab and dictionary
phoneme_vocab = get_vocab_from_lm_labels(lm_labels)
phoneme_to_id = {phoneme: idx for idx, phoneme in enumerate(phoneme_vocab)}
id_to_phoneme = {idx: phoneme for idx, phoneme in enumerate(phoneme_vocab)}

# save the vocab file to be used by tokenizer
with open("phoneme_to_id_test", "w") as file:
    json.dump(phoneme_to_id, file)


print("Transforming the data...")
# create tokenizer, feature extractor and processor
tokenizer = Wav2Vec2CTCTokenizer(
    "phoneme_to_id", unk_token="[UNK]", pad_token="[PAD]", word_delimiter_token="|"
)
feature_extractor = Wav2Vec2FeatureExtractor(
    feature_size=1,
    sampling_rate=16000,
    padding_value=0.0,
    do_normalize=True,
    return_attention_mask=False,
)
processor = Wav2Vec2Processor(feature_extractor=feature_extractor, tokenizer=tokenizer)


# Create the dataset for testing
test_dataset = L2ArcticDataset(
    processor, waveform_paths, lm_labels, accent_labels, gender_labels
)


# Create the data loaders
data_collator = DataCollator(processor=processor, padding=True, device=device, augment=augment)
test_dataloader = DataLoader(
    test_dataset, batch_size=batch_size, collate_fn=data_collator, shuffle=False
)

print("Creating the model...")
# creat the backbone and the model
wav2vec2_backbone = Wav2Vec2ForCTC.from_pretrained(
    pretrained_model_name_or_path=model_path,
    ignore_mismatched_sizes=True,
    ctc_loss_reduction="mean",
    pad_token_id=processor.tokenizer.pad_token_id,
    vocab_size=len(processor.tokenizer),
    output_hidden_states=True,
)
wav2vec2_backbone = wav2vec2_backbone.to(device)
model = MultiTaskWav2Vec2(
    wav2vec2_backbone=wav2vec2_backbone,
    backbone_hidden_size=backbone_hidden_size,
    projection_hidden_size=projection_hidden_size,
    num_accent_class=len(accents),
)


print("Starting the testing...")
#
model.to(device)
criterion = nn.CrossEntropyLoss()
# optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
# min_val_total_loss = 9999
# min_val_ctc_loss = 9999
min_tst_total_loss = 9999
min_tst_ctc_loss = 9999

model.eval()
test_total_loss = 0
test_ctc_loss = 0
test_accent_loss = 0
test_gender_loss = 0
with torch.no_grad():
    for waveform, lm_labels, accent_labels, gender_labels in test_dataloader:
        # Forward pass and loss calculation
        ctc_loss, lm_logits, accent_logits, gender_logits = model(
            waveform, lm_labels
        )
        accent_loss = criterion(accent_logits, accent_labels)
        gender_loss = criterion(gender_logits, gender_labels)
        total_loss = ctc_loss + accent_loss + gender_loss

        if True:  # code for prediction details. not True to skip.
            print("---Test Losses per batch---")
            print(f"Total Loss:  {total_loss}")
            print(f"CTC Loss:    {ctc_loss}")
            print(f"Accent Loss: {accent_loss}")
            print(f"Gender Loss: {gender_loss}")
            print()

        if False:
            lm_preds = torch.argmax(lm_logits, dim=-1)  # (B, P, D=129) -> (B, P)
            print(f"lm_logits.shape: {lm_logits.shape}")
            print(f"lm_preds.shape: {lm_preds.shape}")
            for i in range(len(lm_labels)):
                # break
                print(f"lm_logits[{i}].shape: {lm_logits[i].shape}")
                print(f"lm_preds[{i}].shape: {lm_preds[i].shape}")
                print(f"lm_labels[{i}].shape: {lm_labels[i].shape}")
                #
                # compute_metrics() from Isabel's Baseline 2
                #
                pred_decoded = [phoneme for phoneme in tokenizer.batch_decode(lm_preds[i])]
                label_decoded = [phoneme for phoneme in tokenizer.batch_decode(lm_labels[i], group_tokens=False)]
                print(f"pred_decoded: {pred_decoded}")
                print(f"label_decoded: {label_decoded}")
                pred_str = " ".join(pred_decoded)
                label_str = " ".join(label_decoded)
                print(f"len(pred_str): {len(pred_str)}")
                print(f"len(label_str): {len(label_str)}")
                # per = jiwer.wer(pred_str, label_str)
                # print(f"PER: {per}")
                # out = jiwer.process_words(pred_str, label_str)
                # print(jiwer.visualize_alignment(out))
                """
                PER: 0.5
                sentence 1
                REF: D OY
                HYP: D  P
                        S
                
                number of sentences: 1
                substitutions=1 deletions=0 insertions=0 hits=1
                
                mer=50.00%
                wil=75.00%
                wip=25.00%
                wer=50.00%
                """
                print()
                break

            for i in range(len(accent_labels)):
                break
                print(f"accent_logits[{i}]: {accent_logits[i]}")
                print(f"accent_logits.argmax: {torch.argmax(accent_logits[i])}")
                print(f"accent_labels[{i}]: {accent_labels[i]}")
                print()
                break

            for i in range(len(gender_labels)):
                break
                print(f"gender_logits[{i}]: {gender_logits[i]}")
                print(f"gender_logits.argmax: {torch.argmax(gender_logits[i])}")
                print(f"gender_labels[{i}]: {gender_labels[i]}")
                print()
                break

            # break

        # Keep the lowest test total loss
        if total_loss < min_tst_total_loss:
            min_tst_total_loss = total_loss

        # Keep the lowest test ctc loss
        if ctc_loss < min_tst_ctc_loss:
            min_tst_ctc_loss = ctc_loss

        # Accumulate losses for the test set (for logging)
        test_total_loss += total_loss.item()
        test_ctc_loss += ctc_loss.item()
        test_accent_loss += accent_loss.item()
        test_gender_loss += gender_loss.item()

print("---Test Losses---")
print(f"Total Loss:  {test_total_loss/len(test_dataloader)}")
print(f"CTC Loss:    {test_ctc_loss/len(test_dataloader)}")
print(f"Accent Loss: {test_accent_loss/len(test_dataloader)}")
print(f"Gender Loss: {test_gender_loss/len(test_dataloader)}")

print()
print(f"Minimum CTC Loss: {min_tst_ctc_loss}")
print("Done!")
